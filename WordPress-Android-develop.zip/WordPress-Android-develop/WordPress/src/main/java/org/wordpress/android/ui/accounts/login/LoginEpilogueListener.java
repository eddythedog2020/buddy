package org.wordpress.android.ui.accounts.login;

public interface LoginEpilogueListener {
    void onConnectAnotherSite();

    void onContinue();
}
