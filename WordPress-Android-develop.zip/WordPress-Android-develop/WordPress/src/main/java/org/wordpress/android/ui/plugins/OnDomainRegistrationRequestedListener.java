package org.wordpress.android.ui.plugins;

public interface OnDomainRegistrationRequestedListener {
    void onDomainRegistrationRequested();
}
