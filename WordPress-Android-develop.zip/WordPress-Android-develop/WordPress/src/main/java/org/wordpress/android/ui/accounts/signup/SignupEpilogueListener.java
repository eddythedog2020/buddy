package org.wordpress.android.ui.accounts.signup;

public interface SignupEpilogueListener {
    void onContinue();
}
