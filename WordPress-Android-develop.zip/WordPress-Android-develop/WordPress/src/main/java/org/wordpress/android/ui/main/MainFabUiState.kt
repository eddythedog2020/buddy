package org.wordpress.android.ui.main

data class MainFabUiState(
    val isFabVisible: Boolean,
    val isFabTooltipVisible: Boolean
)
