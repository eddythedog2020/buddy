package org.wordpress.android.ui.main;

public interface BottomNavController {
    void onRequestShowBottomNavigation();
    void onRequestHideBottomNavigation();
}
